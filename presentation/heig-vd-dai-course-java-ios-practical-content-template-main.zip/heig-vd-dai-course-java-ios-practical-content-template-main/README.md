# Java IOs - Practical content template

This repository contains the template to the
[Java IOs](https://github.com/heig-vd-dai-course/heig-vd-dai-course/tree/main/05-java-ios)
practical content.
