package ch.heigvd.dai.ios;

public interface Readable {
  void read(String filename);
}
