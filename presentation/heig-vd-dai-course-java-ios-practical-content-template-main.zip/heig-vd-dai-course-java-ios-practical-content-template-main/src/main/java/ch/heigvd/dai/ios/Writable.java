package ch.heigvd.dai.ios;

public interface Writable {
  void write(String filename, int sizeInBytes);
}
